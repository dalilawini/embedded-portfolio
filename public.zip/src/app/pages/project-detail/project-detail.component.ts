import { Component } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { PROJECTS } from '../../data/projects.data';
import { Project } from '../../models/project.model';

@Component({ selector: 'app-project-detail', imports: [NgFor, NgIf, RouterLink], templateUrl: './project-detail.component.html', styleUrl: './project-detail.component.scss' }) export class ProjectDetailComponent {
    project: Project | undefined;
    videoEmbedUrl: SafeResourceUrl | undefined;
    tutoEmbedUrl: SafeResourceUrl | undefined;
    constructor(route: ActivatedRoute, sanitizer: DomSanitizer) {
        this.project = PROJECTS.find(p => p.slug === route.snapshot.paramMap.get('slug'));
        const videoId = this.getYouTubeVideoId(this.project?.videoUrl);
        this.videoEmbedUrl = videoId
            ? sanitizer.bypassSecurityTrustResourceUrl(`https://www.youtube-nocookie.com/embed/${videoId}`)
            : undefined;
        const tutoId = this.getYouTubeVideoId(this.project?.tutoUrl);
        this.tutoEmbedUrl = tutoId
            ? sanitizer.bypassSecurityTrustResourceUrl(`https://www.youtube-nocookie.com/embed/${tutoId}`)
            : undefined;
    }

    private getYouTubeVideoId(url: string | undefined): string | undefined {
        if (!url) return undefined;
        const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
        return match?.[1];
    }
}
