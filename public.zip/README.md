# Mohamed Ali Lawini — Embedded Portfolio

## Run locally
```bash
npm install
npm start
```
Open `http://localhost:4200`.

## Production build
```bash
npm run build
```

## Content maintenance
- Add or edit projects in `src/app/data/projects.data.ts`.
- Project pages are automatically available at `/projects/<slug>`.
- Place real evidence under `src/assets/projects/` and update each project’s image placeholder.
- Add the CV as `src/assets/documents/Mohamed-Ali-Lawini-CV.pdf`.
- Replace `EMAIL_ADDRESS_HERE` in `src/app/pages/home/home.component.html`.
- Add YouTube URLs to the `videoUrl` field in the project data when available.
